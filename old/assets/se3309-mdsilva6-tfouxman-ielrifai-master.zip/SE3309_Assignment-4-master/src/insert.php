<?php

if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";
        $connection = new PDO($dsn, $username, $password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "INSERT INTO course (courseName, cDescription, programID, programYear, credit) 
                VALUES (:courseName, :cDescription, :programID, :programYear, :credit)";
        
        $courseName = $_POST['courseName'];
        $cDescription = $_POST['cDescription'];
        $programID = $_POST['programID'];
        $programYear = $_POST['programYear'];
        $credit = $_POST['credit'];

        $statement = $connection->prepare($sql);
        
        $statement->bindParam(':courseName', $courseName, PDO::PARAM_STR);
        $statement->bindParam(':cDescription', $cDescription, PDO::PARAM_STR);
        $statement->bindParam(':programID', $programID, PDO::PARAM_STR);
        $statement->bindParam(':programYear', $programYear, PDO::PARAM_STR);
        $statement->bindParam(':credit', $credit, PDO::PARAM_STR);
        
        $statement->execute();
        $connection->exec($statement);

        echo "New course created successfully";


    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}

?>

<?php include "templates/header.php"; ?>

<h2>Add a course</h2>

    <form method="post">
            <label for="courseName">Course Name:</label>
            <input type="text" name="courseName" id="courseName" required>
            <label for="cDescription">Course Description:</label>
            <input type="text" name="cDescription" id="cDescription" size="40" required>
            <label for="programID">Program ID:</label>
            <input type="number" name="programID" id="programID" required>
            <label for="programYear">Program Year:</label>
            <input type="number" name="programYear" id="programYear" required>
            <label for="credit">credit:</label>
            <input type="number" name="credit" id="credit" required>
            
            <input type="submit" name="submit" value="Submit">
    </form>

    <a href="index.php">Back to home</a>

    <?php include "templates/footer.php"; ?>
<?php

if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";
        $connection = new PDO($dsn, $username, $password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM student
                WHERE studentID = :studentID";
        
        $studentID = $_POST['studentID'];

        $statement = $connection->prepare($sql);
        
        $statement->bindParam(':studentID', $studentID, PDO::PARAM_STR);
        
        $statement->execute();
        $connection->exec($statement);

        echo "Student has been deleted from the database";


    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}

?>

<?php include "templates/header.php"; ?>

<h2>Delete student by ID</h2>

    <form method="post">

            <label for="studentID">Student ID:</label>
            <input type="number" name="studentID" id="studentID" required>
            
            <input type="submit" name="submit" value="Submit">
    </form>

    <a href="index.php">Back to home</a>

    <?php include "templates/footer.php"; ?>
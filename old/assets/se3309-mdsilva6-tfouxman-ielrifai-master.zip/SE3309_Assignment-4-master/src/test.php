<?php

if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";
        $connection = new PDO($dsn, $username, $password, $options);
        $sql = "SELECT firstName, lastName, programID, yearOfStudent, birthDay 
                        FROM student
                        WHERE studentID = :studentID";
        $studentID = $_POST['studentID'];
        $statement = $connection->prepare($sql);
        $statement->bindParam(':studentID', $studentID, PDO::PARAM_STR);
        $statement->execute();
        $result = $statement->fetchAll();

        $sql2 = "SELECT *
                    FROM course
                    WHERE course.programID IN (
                        SELECT student.programID
                        FROM student
                        WHERE programID = (
                        SELECT student.programID
                            FROM student
                            WHERE studentID = :studentID
                        )
                    )";
        $studentID = $_POST['studentID'];
        $statement2 = $connection->prepare($sql2);
        $statement2->bindParam(':studentID', $studentID, PDO::PARAM_STR);
        $statement2->execute();
        $result2 = $statement2->fetchAll();

    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?>
<?php require "templates/header.php"; ?>
        
<?php  
if (isset($_POST['submit'])) {
    if ($result && $statement->rowCount() > 0) { ?>
        <h2>Hello Student</h2>

        <table>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Program ID</th>
                    <th>Year of Student</th>
                    <th>Birth Day</th>
                </tr>
            </thead>
            <tbody>
        <?php foreach ($result as $row) { ?>
            <tr>
            <td><?php echo escape($row["firstName"]); ?></td>
            <td><?php echo escape($row["lastName"]); ?></td>
            <td><?php echo escape($row["programID"]); ?></td>
            <td><?php echo escape($row["yearOfStudent"]); ?></td>
            <td><?php echo escape($row["birthDay"]); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <?php } 
    else { ?>
        <blockquote>No results found for <?php echo escape($_POST['studentID']); ?>.</blockquote>
    <?php } 
    if ($result2 && $statement2->rowCount() > 0) { ?>
    <h2>Required Courses</h2>

    <table>
        <thead>
            <tr>
                <th>Course ID</th>
                <th>Course Name</th>
                <th>Course Description</th>
                <th>ProgramID</th>
                <th>Program Year</th>
                <th>Credit</th>
            </tr>
        </thead>
        <tbody>
    <?php foreach ($result2 as $row) { ?>
        <tr>
        <td><?php echo escape($row["courseID"]); ?></td>
        <td><?php echo escape($row["courseName"]); ?></td>
        <td><?php echo escape($row["cDescription"]); ?></td>
        <td><?php echo escape($row["programID"]); ?></td>
        <td><?php echo escape($row["programYear"]); ?></td>
        <td><?php echo escape($row["credit"]); ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<?php } 
else { ?>
    <blockquote>No results found for <?php echo escape($_POST['studentID']); ?>.</blockquote>
<?php }
} ?> 


    <form method="post">
        <label for="studentID">Input Student ID</label>
        <input type="number" id="studentID" name="studentID">
        <input type="submit" name="submit" value="Sign in">
    </form>
    
    <h2>Some helpful links</h2>
    <ul>
    <li>
        <a href="insert.php"><strong>Insert Course</strong></a>: Insert a new course
    </li>
    <li>
        <a href="select.php"><strong>Select Course</strong></a> - Find a course by Program
    </li>
    <li>
        <a href="update.php"><strong>Change program</strong></a>
    </li>
    <li>
        <a href="test.php"><strong>Test Page</strong></a>
    </li>
    </ul>
    


<?php include "templates/footer.php"; ?>


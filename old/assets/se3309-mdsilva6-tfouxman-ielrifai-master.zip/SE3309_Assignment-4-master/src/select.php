<?php
if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";
        $connection = new PDO($dsn, $username, $password, $options);
        $sql = "SELECT course.courseID, courseName, cDescription, course.programID, programName, programYear, credit, courseoffering.offeringID, capacity, instructor, termID, duration, offeringinstance.weekday 
            FROM course 
            INNER JOIN program on course.programID = program.programID
            INNER JOIN courseoffering on course.courseID = courseoffering.courseID 
            INNER JOIN offeringinstance on courseoffering.offeringID = offeringinstance.offeringID

                        WHERE course.programID = :programID and programYear = :programYear
                        ORDER BY courseID";
        $programID = $_POST['programID'];
        $programYear = $_POST['programYear'];
        $statement = $connection->prepare($sql);
        $statement->bindParam(':programID', $programID, PDO::PARAM_STR);
        $statement->bindParam(':programYear', $programYear, PDO::PARAM_STR);
        $statement->execute();
        $result = $statement->fetchAll();
    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}
?>
<?php require "templates/header.php"; ?>
    
<?php  
if (isset($_POST['submit'])) {
    if ($result && $statement->rowCount() > 0) { ?>
        <h2>Courses for selected program and year</h2>

        <table>
            <thead>
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Course Description</th>
                    <th>Program ID</th>
                    <th>Program Name</th>
                    <th>Program Year</th>
                    <th>Credit</th>
                    <th>Offering ID</th>
                    <th>Capacity</th>
                    <th>Instructor</th>
                    <th>Term ID</th>
                    <th>Duration</th>
                    <th>Weekday</th>
                </tr>
            </thead>
            <tbody>
        <?php foreach ($result as $row) { ?>
            <tr>
            <td><?php echo escape($row["courseID"]); ?></td>
            <td><?php echo escape($row["courseName"]); ?></td>
            <td><?php echo escape($row["cDescription"]); ?></td>
            <td><?php echo escape($row["programID"]); ?></td>
            <td><?php echo escape($row["programName"]); ?></td>
            <td><?php echo escape($row["programYear"]); ?></td>
            <td><?php echo escape($row["credit"]); ?></td>
            <td><?php echo escape($row["offeringID"]); ?></td>
            <td><?php echo escape($row["capacity"]); ?></td>
            <td><?php echo escape($row["instructor"]); ?></td>
            <td><?php echo escape($row["termID"]); ?></td>
            <td><?php echo escape($row["duration"]); ?></td>
            <td><?php echo escape($row["weekday"]); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <?php } else { ?>
        <blockquote>No results found for <?php echo escape($_POST['programID']); ?>.</blockquote>
    <?php } 
} ?> 

<h2>Find courses based on program ID and year</h2>

<form method="post">
    <label for="programID">Input Program ID</label>
    <input type="text" id="programID" name="programID">
    <label for="programYear">Input Program Year</label>
    <input type="text" id="programYear" name="programYear">
    <input type="submit" name="submit" name="submit"value="View Results">
</form>
<br>
<br>

<a href="index.php">Back to home page</a><br><br>

<iframe src="programs.php" width=80% height=800px>


<?php require "templates/footer.php"; ?>

window.onload = function onloadfunction() {
    if (document.getElementById("loggedin") == null) {
        document.getElementById("logoutbutton").style.display = "none";
    }
}

function toggleCourses() {
    var x = document.getElementById("requiredCourses");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function loginUser() {
    document.getElementById("loggedin").style.display = "block";
    document.getElementById("logoutbutton").style.display = "block";

    document.getElementById("login").style.display = "none";
}

function logoutUser() {
    document.getElementById("loggedin").style.display = "none";
    document.getElementById("logoutbutton").style.display = "none";

    document.getElementById("login").style.display = "block";
}


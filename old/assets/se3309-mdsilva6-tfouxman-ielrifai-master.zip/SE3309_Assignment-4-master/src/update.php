<?php

if (isset($_POST['submit'])) {
    try  {
        
        require "../config.php";
        require "../common.php";
        $connection = new PDO($dsn, $username, $password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE student
                SET programID = :programID
                WHERE studentID = :studentID";
        
        $studentID = $_POST['studentID'];
        $programID = $_POST['programID'];


        $statement = $connection->prepare($sql);
        
        $statement->bindParam(':studentID', $studentID, PDO::PARAM_STR);
        $statement->bindParam(':programID', $programID, PDO::PARAM_STR);

        
        $statement->execute();
        $connection->exec($statement);

        echo "Student's program updated successfully";


    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}

?>

<?php include "templates/header.php"; ?>

<h2>Change your program</h2>

    <form method="post">

            <label for="studentID">Student ID:</label>
            <input type="number" name="studentID" id="studentID" required>
            <label for="programID">New Program ID:</label>
            <input type="number" name="programID" id="programID" required>

            
            <input type="submit" name="submit" value="Submit">
    </form>

    <a href="index.php">Back to home</a>

    <?php include "templates/footer.php"; ?>
# SE3309_Assignment-4

1. Login with student ID (and select the specific student's required courses)
2. Add course to database
3. Find required courses (courses by program and year)
4. Change student's program
5. Delete student

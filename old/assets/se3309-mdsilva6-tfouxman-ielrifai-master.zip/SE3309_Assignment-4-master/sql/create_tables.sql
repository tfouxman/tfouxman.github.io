DROP SCHEMA courseselector;
CREATE SCHEMA courseselector;
USE courseselector;

CREATE TABLE Program (
    programID       INT NOT NULL AUTO_INCREMENT,
    pDescription    TEXT,
    programName     VARCHAR(50) NOT NULL,
    yearLength      INT NOT NULL,
    PRIMARY KEY (programID, programName)
);

CREATE TABLE Student (
    studentID       INT NOT NULL AUTO_INCREMENT,
    firstName       VARCHAR(25) NOT NULL,
    lastName        VARCHAR(25) NOT NULL,
    programID       INT NOT NULL,
    yearOfStudent   INT NOT NULL,
    birthDay        DATE NOT NULL,
    PRIMARY KEY (studentID),
    FOREIGN KEY (programID) REFERENCES Program(programID)
);

CREATE TABLE Course (
    courseID        INT NOT NULL AUTO_INCREMENT,
    courseName      VARCHAR(60) NOT NULL,
    cDescription    TEXT,
    programID       INT NOT NULL,
    programYear     INT NOT NULL,
    credit          INT NOT NULL,
    PRIMARY KEY (courseID, courseName),
    FOREIGN KEY (programID) REFERENCES Program(programID)
);

CREATE TABLE Preferences (
    preferenceID    INT NOT NULL AUTO_INCREMENT,
    morning         BOOLEAN,
    afternoon       BOOLEAN,
    evening         BOOLEAN,
    monday          BOOLEAN,
    tuesday         BOOLEAN,
    wednesday       BOOLEAN,
    thursday        BOOLEAN,
    friday          BOOLEAN,
    startDate       DATE,
    endDate         DATE,
    PRIMARY KEY (preferenceID)
);

CREATE TABLE StudentPreference (
	studentID		INT NOT NULL,
    preferenceID	INT NOT NULL,
    FOREIGN KEY (studentID) REFERENCES Student(studentID),
    FOREIGN KEY (preferenceID) REFERENCES Preferences(preferenceID)
);

CREATE TABLE Term (
    termID          INT NOT NULL AUTO_INCREMENT,
    termStartDate   DATE NOT NULL,
    termEndDate     DATE NOT NULL,
    termName        VARCHAR(30) NOT NULL,
    PRIMARY KEY (termID)
);

CREATE TABLE CourseOffering (
    offeringID      INT NOT NULL AUTO_INCREMENT,
    courseID        INT NOT NULL,
    capacity        INT NOT NULL,
    instructor      VARCHAR(50),
    termID          INT NOT NULL,
    PRIMARY KEY (offeringID),
    FOREIGN KEY (courseID) REFERENCES Course(courseID),
    FOREIGN KEY (termID) REFERENCES Term(termID)
);

CREATE TABLE OfferingInstance (
	offeringID 		INT NOT NULL,
    startTime 		TIME NOT NULL,
    duration 		INT NOT NULL,
    weekday			INT NOT NULL,
					CHECK (weekday > 0 AND weekday <= 5),
	FOREIGN KEY (offeringID) References CourseOffering(offeringID)
);

CREATE TABLE CourseMatch (
    preferenceID    INT NOT NULL,
    offeringID      INT NOT NULL,
    FOREIGN KEY (preferenceID) REFERENCES Preferences(preferenceID),
    FOREIGN KEY (offeringID) REFERENCES CourseOffering(offeringID)
);

CREATE TABLE ProgramSkeleton (
    programID       INT NOT NULL,
    courseID        INT NOT NULL,
    FOREIGN KEY (programID) REFERENCES Program(programID),
    FOREIGN KEY (courseID) REFERENCES Course(courseID) 
);

CREATE TABLE Draft (
    termID          INT NOT NULL,
    studentID       INT NOT NULL,
    offeringID      INT NOT NULL,
    FOREIGN KEY (termID) REFERENCES Term(termID),
    FOREIGN KEY (studentID) REFERENCES Student(studentID),
    FOREIGN KEY (offeringID) REFERENCES CourseOffering(offeringID)
);

DESCRIBE student;
DESCRIBE program;
DESCRIBE preferences;
DESCRIBE studentpreference;
DESCRIBE course;
DESCRIBE courseoffering;
DESCRIBE coursematch;
DESCRIBE draft;
DESCRIBE term;
DESCRIBE programskeleton;
DESCRIBE offeringinstance;

# The Order In Which These Files Are Run Matters

1. Program
2. Student
3. Term
4. Course
5. ProgramSkeleton
6. CourseOffering
7. OfferingInstance
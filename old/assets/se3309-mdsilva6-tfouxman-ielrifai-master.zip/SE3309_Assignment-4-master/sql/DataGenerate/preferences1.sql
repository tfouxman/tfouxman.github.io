INSERT INTO preferences VALUES 
	(0, true, true, true, true, true, true, true, true, null, null),
	(0, true, true, false, true, true, true, true, true, null, null);
# Note on generate.sql and DataGenerate/

generate_data.sql contains all of the code from the files from the DataGenerate folder
<?php

require "config.php";

try {
  $connection = new PDO("mysql:host=$host", $username, $password, $options);
  $sql = file_get_contents("sql/create_tables.sql");
  $connection->exec($sql);
  echo "Database and tables created successfully.";
  $sql = file_get_contents("sql/generate_data.sql");
  $connection->exec($sql);
  echo "Tables populated.";
} catch(PDOException $error) {
  echo $sql . "<br>" . $error->getMessage();
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : MonoBehaviour
{
    [Header("Set in Inspector")]
    public float rotationsPerSecond = 0f;

    [Header("Set Dynamically")]
    

    public GameObject shield, middleShield, outerShield;

    public void UpdateShield()
    {        
        if (Hero.hero.shieldLevel == 3f)
        {
            shield.SetActive(true);
            middleShield.SetActive(true);
            outerShield.SetActive(true);
        }

        if (Hero.hero.shieldLevel == 2f)
        {
            shield.SetActive(true);
            middleShield.SetActive(true);
            outerShield.SetActive(false);
        }
        if (Hero.hero.shieldLevel == 1f)
        {
            shield.SetActive(true);
            middleShield.SetActive(false);
            outerShield.SetActive(false);
        }
        if (Hero.hero.shieldLevel == 0f)
        {
            shield.SetActive(false);
            middleShield.SetActive(false);
            outerShield.SetActive(false);
        }
        Debug.Log(Hero.hero.shieldLevel);
        Hero.hero.allowDamage = false;
    }
    
        
}



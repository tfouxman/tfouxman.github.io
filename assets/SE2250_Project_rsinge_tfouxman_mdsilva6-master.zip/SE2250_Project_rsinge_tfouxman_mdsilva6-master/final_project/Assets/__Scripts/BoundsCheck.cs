﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoundsCheck : MonoBehaviour
{
    [Header("Set in Inspector")]

    public float radius = 1f;

    [Header("Set Dynamically")]

    public bool isOnScreen;

    public float camWidth;

    public float camHeight;

    void Awake()
    {
        isOnScreen = true;

        

        camHeight = Camera.main.orthographicSize;

        camWidth = camHeight * Camera.main.aspect;

    }

    void LateUpdate()

    {
        Vector3 pos = transform.position;

        //restricting x-axis movement
        if (gameObject.tag == "Player")
        {
            if (pos.x > camWidth - radius)
            {
                pos.x = camWidth - radius;
            }

            if (pos.x < -camWidth + radius)
            {
                pos.x = -camWidth - radius;
            }

            //restricting y-axis movement
            if (pos.y > camHeight + radius)
            {
                pos.y = camHeight - radius;
            }

            if (pos.y < -camHeight + radius)
            {
                pos.y = -camHeight + radius;
            }
        }

        else if (gameObject.tag == "projectile")
        {
            if (pos.y > camHeight + radius)
            {
                isOnScreen = false;
            }
        }

        else if (gameObject.tag == "enemyR")
        {
            if (pos.x > camWidth + 10)
            {
                isOnScreen = false;
            }
        }

        else if (gameObject.tag == "enemyL")
        {
            if (pos.x < camWidth - 10)
            {
                isOnScreen = false;
            }
        }

        else
        {
            
            if (pos.y < -camHeight + radius - 3)
            {
                isOnScreen = false;
            }
        }
    
        transform.position = pos;

    }

    void OnDrawGizmos()
    {
        if (!Application.isPlaying) return;

        Vector3 boundSize = new Vector3(camWidth * 2, camHeight * 2, 0.1f);

        Gizmos.DrawWireCube(Vector3.zero, boundSize);
    }
}

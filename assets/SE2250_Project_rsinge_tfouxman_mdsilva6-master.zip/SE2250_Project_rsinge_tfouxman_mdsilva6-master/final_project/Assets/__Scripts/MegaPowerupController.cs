﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MegaPowerupController : MonoBehaviour
{
    public float timeLeft = 15.0f;

    static public MegaPowerupController mega;

    static public bool clock = false;

    public bool play = true;
    public bool stop = false;

    void Awake()
    {
        if (mega == null)
        {
            mega = this; // Set the Singleton                                   
        }
        else
        {
            Debug.LogError("Hero.Awake() - Attempted to assign second Hero.S!");
        }       
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (clock)
        {
            timeLeft -= Time.deltaTime;
            //the audio file is not long enough so some adjustments have to be made so it plays for the full duration of the powerup
            if (timeLeft <= 7 && play)
            {
                GameAudio.gameAudio.StopMegaMusic();
                GameAudio.gameAudio.PlayMegaMusic();
                play = false;
            }
            if (timeLeft <= 3 && !play && !stop)
            {
                play = true;
                stop = true;
            }
            if (timeLeft < 0)
            {
                ResetTime();
                ResetEnemySpeed();
                ResetRespawn();
                ResetSpeed();
                //ensure that the hero reappears - there was a bug where the hero renderer was turned off after the mega powerup
                Hero.hero.rend1.enabled = true;
                Hero.hero.rend2.enabled = true;
                Hero.hero.rend3.enabled = true;
                Hero.hero.rend4.enabled = true;
                GameAudio.gameAudio.StopMegaMusic();
                stop = false;
                play = true;
            }
            Hero.hero.allowDamage = !clock;
        }
    }

    public void SlowEnemies()
    {
        StartTime();
        Enemy.speed = 4.0f;
        Enemy_2.waveFrequency = 4;
        
    }

    public void RespawnP()
    {
        if (Main.S.level == 1)
        {
            Main.S.Respawn();
        }
        else
        {
            Main.S.RespawnComplex();
            if (Main.S.level >= 3)
            {
                Main.S.SpawnHorizontal();
            }
        }
    }

    public void IncreaseRespawn()
    {
        if (Main.S.level <= 2)
        {
            InvokeRepeating("RespawnP", 0.1f, 1f);
        }
        else
        {
            InvokeRepeating("RespawnP", 0.1f, 0.5f);
        }
    }

    public void ResetRespawn()
    {
        CancelInvoke("RespawnP");
    }

    public void ResetEnemySpeed()
    {
        Enemy.speed = 10.0f;
        Enemy_2.waveFrequency = 2;
    }

    public void IncreaseSpeed()
    {
        Hero.hero.speed = 55;
    }

    public void ResetSpeed()
    {
        Hero.hero.speed = 30;
    }

    public void StartTime()
    {
        clock = true;
    }

    public void ResetTime()
    {
        clock = false;
        timeLeft = 10.0f;
    }
}

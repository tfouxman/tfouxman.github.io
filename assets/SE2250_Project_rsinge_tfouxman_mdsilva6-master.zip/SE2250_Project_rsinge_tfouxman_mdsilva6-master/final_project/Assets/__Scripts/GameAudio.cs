﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class GameAudio : MonoBehaviour
{
    static public GameAudio gameAudio;
    public AudioClip gameStart;
    public AudioClip laser;
    public AudioClip blaster;
    public AudioClip enemyDeath;
    public AudioClip megaSound;
    public AudioClip megaUp;
    public AudioClip shieldUp;
    public AudioClip shieldDown;
    public AudioClip ammoPickup;


    public AudioSource audio;
    // Start is called before the first frame update
    void Awake()
    {
        gameAudio = this;
    }

    void Start()
    {
        audio = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void PlayGameStart()
    {
        audio.PlayOneShot(gameStart);
    }

    public void PlayLaser()
    {
        audio.PlayOneShot(laser);
    }

    public void PlayBlaster()
    {
        audio.PlayOneShot(blaster);
    }

    public void PlayEnemyDeath()
    {
        audio.PlayOneShot(enemyDeath);
    }

    public void PlayMegaUp()
    {
        audio.PlayOneShot(megaUp);
    }

    public void PlayMegaMusic()
    {
        audio.PlayOneShot(megaSound, 0.1f);
    }

    public void StopMegaMusic()
    {
        audio.Stop();
    }

    public void PlayShieldUp()
    {
        audio.PlayOneShot(shieldUp);
    }

    public void PlayShieldDown()
    {
        audio.PlayOneShot(shieldDown);
    }

    public void PlayAmmoPickup()
    {
        audio.PlayOneShot(ammoPickup);
    }
}
    

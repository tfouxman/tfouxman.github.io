﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Set in Inspector: Enemy")]
    static public float speed = 10f;
    public float fireRare = 0.3f;
    public float health = 10;
    public int score = 100;

    private BoundsCheck _bndCheck;

    public GameObject shieldPowerup;
    public GameObject megaPowerup;
    public int shieldDropRand;
    public int megaDropRand;
    public bool drop = true;

    void Awake()
    {
        _bndCheck = GetComponent<BoundsCheck>();
        shieldDropRand = Random.Range(0, 5);
        megaDropRand = Random.Range(0, 8);
    }

    public Vector3 pos
    {
        get
        {
            return this.transform.position;
        }
        set
        {
            this.transform.position = value;
        }
    }

    void Update()
    {
        
        if (gameObject.tag != "control") { Move(); }
        if (!_bndCheck.isOnScreen && (gameObject.tag == "enemy"))
        {
            Destroy(gameObject);
        }
        else if (!_bndCheck.isOnScreen && (gameObject.tag == "enemyL") && (transform.position.x < -35))
        {
            Destroy(gameObject);
        }
        else if (!_bndCheck.isOnScreen && (gameObject.tag == "enemyR") && (transform.position.x > 35))
        {
            Destroy(gameObject);
        }



    }

    public virtual void Move()
    {
        if (gameObject.tag == "enemyL")
        {
            Vector3 tempPos = pos;
            tempPos.x -= speed * Time.deltaTime;
            pos = tempPos;
        }
        else if (gameObject.tag == "enemyR")
        {
            Vector3 tempPos = pos;
            tempPos.x += speed * Time.deltaTime;
            pos = tempPos;
        }
        else
        {
            Vector3 tempPos = pos;
            tempPos.y -= speed * Time.deltaTime;
            pos = tempPos;
        }
    }

    void OnTriggerEnter(Collider coll)
    {
        GameObject otherGO = coll.gameObject;

        if (otherGO.tag == "projectile")
        {
            if (GetComponent<Enemy_1>() != null)
            {
                health = health - 5;
                if (health == 0)
                {
                    if (shieldDropRand == 2 && Hero.hero.shieldLevel < 3 && !MegaPowerupController.clock && drop)
                    {
                        Shield_Powerup.shieldPowerups[0] = Instantiate(shieldPowerup, transform.position, Quaternion.identity);
                        drop = false;
                        
                    }
                    Destroy(gameObject);
                    Main.S.AddScore(score);
                    GameAudio.gameAudio.PlayEnemyDeath();
                   
                }
                
            }
            else if (GetComponent<Enemy_2>() != null)
            {
                health = health - 3;
                if (health < 0)
                {
                    if (megaDropRand == 2 && !MegaPowerupController.clock && drop)
                    {
                        MegaPowerup.megaPowerups[0] = Instantiate(megaPowerup, transform.position, Quaternion.identity);
                        drop = false;
                    }
                    Destroy(gameObject);
                    Main.S.AddScore(score);
                    GameAudio.gameAudio.PlayEnemyDeath();
                }

            }
            else if (GetComponent<Enemy>() != null)
            {
                if (shieldDropRand == 2 && Hero.hero.shieldLevel < 3 && !MegaPowerupController.clock && drop)
                {
                    Shield_Powerup.shieldPowerups[0] = Instantiate(shieldPowerup, transform.position, Quaternion.identity);
                    drop = false;

                }
                Destroy(gameObject);
                Main.S.AddScore(score);
                GameAudio.gameAudio.PlayEnemyDeath();
                
            }
            Destroy(otherGO);
            

        }
        else
        {

            print("Enemy hit by non-ProjectileHero: " + otherGO.name);

        }

        if (Main.S.score > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore", Main.S.score);
            Main.S.UpdateHighScore();
        }
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MegaPowerup : MonoBehaviour
{
    static public GameObject[] megaPowerups = new GameObject[3];

    public float speed = 5f;

    private BoundsCheck _bndCheck;
    // Start is called before the first frame update
    void Start()
    {
        _bndCheck = GetComponent<BoundsCheck>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 tempPos = transform.position;
        tempPos.y -= speed * Time.deltaTime;
        transform.position = tempPos;
        if (!_bndCheck.isOnScreen)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider coll)
    {
        GameObject otherGO = coll.gameObject;

        if (otherGO.tag == "Player")
        {
            MegaPowerupController.mega.SlowEnemies();
            MegaPowerupController.mega.IncreaseRespawn();
            MegaPowerupController.mega.IncreaseSpeed();
            Destroy(gameObject);
            GameAudio.gameAudio.PlayMegaUp();
            GameAudio.gameAudio.PlayMegaMusic();
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_1 : Enemy
{
    public string id;

    void Start()
    {
        score = 200;
        if (pos.x < 0)
        {
            id = "left";
        }
        else
        {
            id = "right";
        }
    }

    public override void Move()
    {
        Vector3 tempPos = pos;
        if (id == "left")
        {
            tempPos.x += 0.7f*speed * Time.deltaTime;
            pos = tempPos;
        }
        else if (id == "right")
        {
            tempPos.x -= 0.7f*speed * Time.deltaTime;
            pos = tempPos;
        }
        
        base.Move();
        
    }
}

﻿using System.Collections;

using System.Collections.Generic;

using UnityEngine;

using UnityEngine.UI;


public class Hero : MonoBehaviour
{

    static public Hero hero; // Singleton  

    public bool allowDamage = true;

    public delegate void WeaponFireDelegate();

    public WeaponFireDelegate fireDelegate;

    public Weapon weapon;

    [Header("Set in Inspector")]

    // These fields control the movement of the ship

    public float speed = 30;

    public float rollMult = -45;

    public float pitchMult = 30;

    public GameObject projectilePrefab;

    public float gameRestartDelay = 2f;

    public float timeLeft = 2.0f;

    [Header("Set Dynamically")]

    public float shieldLevel = 0;

    private GameObject _lastTriggerGo = null;

    public Shield heroShield;

    public Renderer rend1;
    public Renderer rend2;
    public Renderer rend3;
    public Renderer rend4;

    public int ammo;
    public Text ammoDisplay;

    void Awake()
    {
      

        if (hero == null)
        {


            hero = this; // Set the Singleton                                   

        }
        else
        {

            Debug.LogError("Hero.Awake() - Attempted to assign second Hero.S!");

        }

        hero.shieldLevel = 3;

        rend1 = transform.Find("Wing").gameObject.GetComponent<Renderer>();
        rend2 = transform.Find("Cockpit").gameObject.transform.Find("Cube").gameObject.GetComponent<Renderer>();
        rend3 = transform.Find("Weapon").gameObject.transform.Find("Barrel").gameObject.GetComponent<Renderer>();
        rend4 = transform.Find("Weapon").gameObject.transform.Find("Collar").gameObject.GetComponent<Renderer>();

        ammo = 30;
        ammoDisplay.text = ammo.ToString();
    }

    public void AddAmmo()
    {
        if (Main.S.level <= 2)
        {
            ammo += 30;
        }
        else if (Main.S.level == 3)
        {
            ammo += 50;
        }
        else if (Main.S.level == 4)
        {
            ammo += 80;
        }
        ammoDisplay.text = ammo.ToString();
    }

    public void RemoveAmmo1()
    {
        ammo -= 1;
        ammoDisplay.text = ammo.ToString();
    }

    public void RemoveAmmo3()
    {
        ammo -= 3;
        ammoDisplay.text = ammo.ToString();
    }

    void Update()
    {
        
        

        // Pull in information from the Input class

        float xAxis = Input.GetAxis("Horizontal");                            

        float yAxis = Input.GetAxis("Vertical");                              



        // Change transform.position based on the axes

        Vector3 pos = transform.position;

        pos.x += xAxis * speed * Time.deltaTime;

        pos.y += yAxis * speed * Time.deltaTime;

        transform.position = pos;



        // Rotate the ship to make it feel more dynamic                      

        transform.rotation = Quaternion.Euler(yAxis * pitchMult, xAxis * rollMult, 0);
        
        if (Input.GetAxis("Jump") == 1 && fireDelegate != null)
        {            


            fireDelegate();                                                  


        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            GameObject weaponGO = transform.Find("Weapon").gameObject;
           
            weapon = weaponGO.GetComponent<Weapon>();
            if (weapon.type == WeaponType.blaster)
            {
                weapon.type = WeaponType.spread;
            }
            else if (weapon.type == WeaponType.spread)
            {
                weapon.type = WeaponType.blaster;
            }
        }

        if (!allowDamage)
        {
           // Renderer rend1 = transform.Find("Wing").gameObject.GetComponent<Renderer>();
            //Renderer rend2 = transform.Find("Cockpit").gameObject.transform.Find("Cube").gameObject.GetComponent<Renderer>();
            //Renderer rend3 = transform.Find("Weapon").gameObject.transform.Find("Barrel").gameObject.GetComponent<Renderer>();
            //Renderer rend4 = transform.Find("Weapon").gameObject.transform.Find("Collar").gameObject.GetComponent<Renderer>();
            timeLeft -= Time.deltaTime;
            if(timeLeft < 0)
            {
                _lastTriggerGo = null;
                allowDamage = true;
                timeLeft = 2.0f;
                rend1.enabled = true;
                rend2.enabled = true;
                rend3.enabled = true;
                rend4.enabled = true;
            }
            if((timeLeft%0.2) < 0.1)
            {
                rend1.enabled = false;
                rend2.enabled = false;
                rend3.enabled = false;
                rend4.enabled = false;
            }
            else if ((timeLeft%0.2)> 0.1)
            {
                rend1.enabled = true;
                rend2.enabled = true;
                rend3.enabled = true;
                rend4.enabled = true;
            }
            

        }
    }

    void Fire()
    {                                                        

        GameObject projGO = Instantiate<GameObject>(projectilePrefab);

        Vector3 temp = new Vector3(0, 3.0f, 0);
        projGO.transform.position = transform.position+temp;

        Rigidbody rigidB = projGO.GetComponent<Rigidbody>();

        Projectile proj = projGO.GetComponent<Projectile>();                 
        proj.type = WeaponType.blaster;
        float tSpeed = Main.GetWeaponDef(proj.type).velocity;
        rigidB.velocity = Vector3.up * tSpeed;
    }

    void OnCollisionEnter(Collision other)
    {

        Transform rootT = other.gameObject.transform.root;
        GameObject gO = rootT.gameObject;

        if (gO == _lastTriggerGo)
        {
            return;
        }
        _lastTriggerGo = gO;

        if (gO.tag == "enemy" || gO.tag == "enemyL" || gO.tag == "enemyR")
        {
            if (allowDamage)
            {
                takeDamage(gO);
            }
        }
        else
        {
            print("Triggered by non-Enemy: " + gO.name);
        }

        //this just confirms that the powerups disappear after collision
        //to fix the bug were the powerup is applied but the object does not disappear
        if (gO.tag == "shieldUp")
        {
            Destroy(gO);
        }

        if (gO.tag == "megaUp")
        {
            Destroy(gO);
        }
    }
    /*
    public float shieldLevel
    {
        get
        {
            return (_shieldLevel);
        }
        set
        {
            _shieldLevel = Mathf.Min(value, 4);
            if (value < 0)
            {
                Destroy(this.gameObject);
                Main.S.DelayedRestart(gameRestartDelay);
            }
        }

    }
    */

    public void takeDamage(GameObject gO)
    {
        shieldLevel--;
        if (shieldLevel < 0)
        {
            
            Destroy(this.gameObject);
            Main.S.DelayedRestart(gameRestartDelay);
            
        }
        GameAudio.gameAudio.PlayShieldDown();
        heroShield = GetComponent<Shield>();
        heroShield.UpdateShield();
        Main.S.AddScore(gO.GetComponent<Enemy>().score);
        if (Main.S.score > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore", Main.S.score);
            Main.S.UpdateHighScore();
        }
        Destroy(gO);
               
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ammo : MonoBehaviour
{
    public float speed = 10f;

    private BoundsCheck _bndCheck;

    void Awake()
    {
        _bndCheck = GetComponent<BoundsCheck>();
    }

    public Vector3 pos
    {
        get
        {
            return this.transform.position;
        }
        set
        {
            this.transform.position = value;
        }
    }

    void Update()
    {
        transform.Rotate(Vector3.up, 5*speed * Time.deltaTime);
        transform.Rotate(Vector3.left, 5*speed * Time.deltaTime);

        Vector3 tempPos = pos;
        tempPos.y -= speed * Time.deltaTime;
        pos = tempPos;

        if (!_bndCheck.isOnScreen)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider coll)
    {
        GameObject otherGO = coll.gameObject;

        if (otherGO.tag == "Player")
        {
            Hero.hero.AddAmmo();
            GameAudio.gameAudio.PlayAmmoPickup();
            Destroy(gameObject);
        }
    }

}

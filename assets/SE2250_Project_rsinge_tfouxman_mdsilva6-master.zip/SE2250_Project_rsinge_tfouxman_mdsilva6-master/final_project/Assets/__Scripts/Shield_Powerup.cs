﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield_Powerup : MonoBehaviour
{
    static public GameObject[] shieldPowerups = new GameObject[3];

    public Shield heroShield;

    public float speed = 5f;

    private BoundsCheck _bndCheck;

    // Start is called before the first frame update
    void Start()
    {
        _bndCheck = GetComponent<BoundsCheck>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 tempPos = transform.position;
        tempPos.y -= speed * Time.deltaTime;
        transform.position = tempPos;
        if (!_bndCheck.isOnScreen)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider coll)
    {
        
        GameObject otherGO = coll.gameObject;
        
        if (otherGO.tag == "Player")
        {
            if (Hero.hero.allowDamage)
            {
                if (Hero.hero.shieldLevel < 3)
                {
                    IncreaseShield();
                    GameAudio.gameAudio.PlayShieldUp();
                }
                Destroy(gameObject);
            }
           
        }
        
    }

    void IncreaseShield()
    {
        Hero.hero.shieldLevel++;
        heroShield = Hero.hero.GetComponent<Shield>();
        heroShield.UpdateShield();
        
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour
{

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Resume();
        }

    }

    public GameObject playGameButton;
    public GameObject playTutorialButton;
    public GameObject quitGameButton;
  
    public void PlayGame()
    {
        SceneManager.LoadScene("_Scene_o");
        ContinueGame();
    }

    public void PlayTutorial()
    {
        ContinueGame();
        SceneManager.LoadScene("_Scene_o_Tutorial");
    }

    public void QuitGame()
    {
        //SceneManager.UnloadSceneAsync("MainMenu");
        Application.Quit();
    }

    public void Resume()
    {
        SceneManager.UnloadSceneAsync("InGameMenu");
        ContinueGame();
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    void ContinueGame()
    {
        Time.timeScale = 1;
    }
}

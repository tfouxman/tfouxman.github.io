﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Main : MonoBehaviour
{
    public static Main S;
    public GameObject objEnemy_0, objEnemy_1, objEnemy_2, ammoBox;
    
    public GameObject[] ammoBoxes = new GameObject[3];

    public GameObject[] enemies = new GameObject[3];

    public int[] start_pos = {-20,-10, 0, 10, 20 };
    public int[] type2StartPosRight = { -50, -40, -30, -20, -10 };
    public int[] type2StartPosLeft = { 50, 40, 30, 20, 10 };
    public int[] type0_2StartPosComplex = { -20, -15, -10, -5, 0, 5, 10, 15, 20 };
    public int[] verticalStartPos = { 30, 20, 10, 0, -10, -20, -30 };


    public int rand, rand2, rand3, rand4, rand5, rand6;
    public Text scoreText;
    public Text highScoreText;
    public int score;

    public int level;

    public Text levelText;

    public WeaponDefinition[] weaponDefintions;

    static Dictionary<WeaponType, WeaponDefinition> weaponDict;

    public Text tutorialText;
    public Text tutorialText2;
    public float tutorialTime = 7.0f;
    public float textTime = 5.0f;
    public bool startGame = false;
    public bool tutorialActive = false;
    public bool ammoSpawned = false;
    public bool enemySpawned = false;
    public bool enemySpawned2 = false;
    public int tutorialStep = 0;

    void Awake()
    {
        Screen.SetResolution(540, 720, true);

        S = this;

        weaponDict = new Dictionary<WeaponType, WeaponDefinition>();

        foreach (WeaponDefinition def in weaponDefintions)
        {
            weaponDict[def.type] = def;
        }

        level = 1;

        Scene currentScene = SceneManager.GetActiveScene();

        string sceneName = currentScene.name;

        if (tutorialTime >= 0 && sceneName == "_Scene_o_Tutorial")
        {
            tutorialActive = true;
            tutorialStep += 1;
            RunTutorial();
            Debug.Log(tutorialStep);
        }
        else if (sceneName == "_Scene_o")
        {
            StartGame();
        }
    }

    static public WeaponDefinition GetWeaponDef(WeaponType wt)
    {
        if (weaponDict.ContainsKey(wt))
        {
            return (weaponDict[wt]);
        }
        else
        {
            return (new WeaponDefinition());
        }
    }
    // Use this for initialization


    

    void Start()
    {
        score = 0;
        highScoreText.text = "High Score: " + PlayerPrefs.GetInt("HighScore");
        UpdateScore();
        
        
        GameAudio.gameAudio.PlayGameStart();
        /*
        InvokeRepeating("Respawn", 2, 3);
        InvokeRepeating("SpawnAmmo", 10, 10);
        */
    }
    float timer = 7.0f;

    void Update()
    {
        tutorialTime -= Time.deltaTime;

        if (tutorialActive)
        {
            RunTutorial();
            /*textTime -= Time.deltaTime;
            if (textTime < 0)
            {
                textTime = 5.0f;
                tutorialStep += 1;
                Debug.Log(tutorialStep);
            }*/

            if (tutorialStep ==  1&& (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.DownArrow)
                || Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.S))){
                tutorialStep = 2;
            }
            if (tutorialStep ==2 && Input.GetKeyDown(KeyCode.Space))
            {
                tutorialStep = 3;
            }
            if(tutorialStep ==3 && Input.GetKeyDown(KeyCode.C)){
                tutorialStep = 4;
            }

            if (timer >= 0)
            {
                timer -= Time.deltaTime;
                return;
            }
            else if (tutorialStep == 4)
            {
                timer = 6.0f;

                tutorialStep = 6;
                
            }
            else if(tutorialStep ==6)
            {
                timer = 6.0f;

                tutorialStep = 8;

            }
            else if (tutorialStep == 8)
            {
                timer = 6.0f;

                tutorialStep = 10;

            }


        }

        rand = Random.Range(0, 3);
        rand2 = Random.Range(0, 2);
        rand3 = Random.Range(0, 5);
        rand4 = Random.Range(0, 9);
        rand5 = Random.Range(0, 7);
        rand6 = Random.Range(0, 2);

        
        

        if (score >= 5000 && level == 1)
        {
            level = 2;
            CancelInvoke("Respawn");
            InvokeRepeating("RespawnComplex", 5, 2);
        }

        if (score >= 15000 && level == 2)
        {
            level = 3;
            CancelInvoke("RespawnComplex");
            InvokeRepeating("SpawnHorizontal", 5, 2);
            InvokeRepeating("RespawnComplex", 5, 2);
        }
        if (score >= 30000 && level == 3)
        {
            level = 4;
            CancelInvoke("RespawnComplex");
            CancelInvoke("SpawnHorizontal");
            InvokeRepeating("SpawnHorizontal", 5, 1);
            InvokeRepeating("RespawnComplex", 5, 1);
        }

        Scene currentScene = SceneManager.GetActiveScene();

        string sceneName = currentScene.name;


        if (Input.GetKeyDown(KeyCode.Escape)&& SceneManager.sceneCount == 1)
        {
            PauseGame();
            SceneManager.LoadScene("InGameMenu", LoadSceneMode.Additive);
        }

        levelText.text = level.ToString();
    }

    public void Respawn()
    {
        if (rand == 0)
        {
            enemies[0] = Instantiate(objEnemy_0, new Vector3(start_pos[rand3], 50, 0), Quaternion.identity);
            enemies[0].tag = "enemy";

        }
        else if (rand == 1)
        {

            if (rand2 == 0)
            {
                enemies[1] = Instantiate(objEnemy_1, new Vector3(30, 50, 0), Quaternion.identity);
                enemies[1].tag = "enemy";
            }
            if (rand2 == 1)
            {
                enemies[1] = Instantiate(objEnemy_1, new Vector3(-30, 50, 0), Quaternion.identity);
                enemies[1].tag = "enemy";
            }

        }
        else
        {
            enemies[2] = Instantiate(objEnemy_2, new Vector3(start_pos[rand3], 50, 0), Quaternion.identity);
            enemies[2].tag = "enemy";

        }
    }

    public void RespawnComplex()
    {
        if (rand == 0)
        {
            enemies[0] = Instantiate(objEnemy_0, new Vector3(type0_2StartPosComplex[rand4], 50, 0), Quaternion.identity);
            enemies[0].tag = "enemy";

        }
        else if (rand == 1)
        {

            if (rand2 == 0)
            {
                enemies[1] = Instantiate(objEnemy_1, new Vector3(type2StartPosLeft[rand3], 50, 0), Quaternion.identity);
                enemies[1].tag = "enemy";
            }
            if (rand2 == 1)
            {
                enemies[1] = Instantiate(objEnemy_1, new Vector3(type2StartPosRight[rand3], 50, 0), Quaternion.identity);
                enemies[1].tag = "enemy";
            }

        }
        else
        {
            enemies[2] = Instantiate(objEnemy_2, new Vector3(type0_2StartPosComplex[rand4], 50, 0), Quaternion.identity);
            enemies[2].tag = "enemy";

        }
    }

    public void SpawnHorizontal()
    {
        if ((rand2 == 0) || (level == 3)) //spawn type0
        {
            if (rand6 == 0)
            {
                enemies[0] = Instantiate(objEnemy_0, new Vector3(-40, verticalStartPos[rand5], 0), Quaternion.identity);//move right
                enemies[0].tag = "enemyR";
            }
            else if (rand6 == 1)
            {
                enemies[0] = Instantiate(objEnemy_0, new Vector3(40, verticalStartPos[rand5], 0), Quaternion.identity);//move left
                enemies[0].tag = "enemyL";
            }
            
        }
        if (rand2 == 1 && (level == 4)) //spawn type 2
        {
            if (rand6 == 0)
            {
                enemies[2] = Instantiate(objEnemy_2, new Vector3(-40, verticalStartPos[rand5], 0), Quaternion.identity);//move right
                enemies[2].tag = "enemyR";
            }
            else if (rand6 == 1)
            {
                enemies[2] = Instantiate(objEnemy_2, new Vector3(-40, verticalStartPos[rand5], 0), Quaternion.identity);//move left
                enemies[2].tag = "enemyL";
            }
            
        }

    }

    public void SpawnAmmo()
    {
        ammoBoxes[0] = Instantiate(ammoBox, new Vector3(start_pos[rand3], 50, 0), Quaternion.identity);
    }

    public void DelayedRestart(float delay)
    {
        Invoke("Restart", delay);
        
    }

    public void Restart()
    {
        SceneManager.LoadScene("_Scene_o");
    }

    void UpdateScore()
    {
        scoreText.text = "Score: " + score; 
    }

    public void UpdateHighScore()
    {
        highScoreText.text = "High Score: " + PlayerPrefs.GetInt("HighScore");
    }

    public void AddScore(int enemyScore)
    {
        score += enemyScore;
        S.UpdateScore();
    }

    void RunTutorial()
    {
        switch (tutorialStep)
        {

            case 1:
                tutorialText.text = "Use the arrow keys or WASD to move";
                break;
            case 2:
                tutorialText.text = "Press SPACE to shoot";
                break;
            case 3:
                tutorialText.text = "Press C to switch weapons";
                break;
            case 4:
                tutorialText.text = "Collect the boxes for ammo";
                if (!ammoSpawned)
                {
                    SpawnAmmo();
                    ammoSpawned = true;
                }
                break;
            case 6:
                tutorialText.text = "Avoid colliding with enemies";
                tutorialText2.text = "(Try colliding with one)";
                if (!enemySpawned)
                {
                    enemySpawned = true;
                    enemies[0] = Instantiate(objEnemy_0, new Vector3(0, 50, 0), Quaternion.identity);
                    enemies[0].tag = "enemy";
                }
                break;
            case 8:
                
                tutorialText2.text = "";
                tutorialText.text = "Destroy enemies and collect poweups";
                if (!enemySpawned2)
                {
                    enemySpawned2 = true;
                    enemies[0] = Instantiate(objEnemy_0, new Vector3(0, 50, 0), Quaternion.identity);
                    enemies[0].tag = "enemy";
                    enemies[0].GetComponent<Enemy>().shieldDropRand = 2;
                }
                break;
            case 10:

                tutorialText.text = "Good luck!";
                StartGame();
                tutorialActive = false;
                SceneManager.LoadScene("_Scene_o");
                break;
        }
    }

    void StartGame()
    {
        startGame = true;
        //tutorialText.text = "";
        InvokeRepeating("Respawn", 2, 3);
        InvokeRepeating("SpawnAmmo", 10, 10);
    }

    void PauseGame()
    {
        Time.timeScale = 0;
    }
    
}

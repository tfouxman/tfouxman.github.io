﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum WeaponType
{
    none, //default - no weapon
    
    blaster, //shoots one bullet

    spread, //shoots three bullets

    shield //changes the shield level

}

[System.Serializable]

public class WeaponDefinition
{

    public WeaponType type = WeaponType.none;

    public GameObject projectilePrefab;

    public Color projectileColor = Color.white;

    public float damageOnHit = 0;

    public float shotDelay = 0;

    public float velocity = 20;

}


public class Weapon : MonoBehaviour
{
    static public Transform PROJECTILE_ANCHOR;

    [Header("Set Dynamically")]
    [SerializeField]

    private WeaponType _type = WeaponType.none;

    public WeaponDefinition def;

    public GameObject collar;

    public float lastShotTime; // Time last shot was fired

    private Renderer _collarRend;

    void Start()
    {

        collar = transform.Find("Collar").gameObject;

        _collarRend = collar.GetComponent<Renderer>();

        SetType(_type);                                                    



        // Dynamically create an anchor for all Projectiles

        if (PROJECTILE_ANCHOR == null)
        {                                     

            GameObject go = new GameObject("_ProjectileAnchor");

            PROJECTILE_ANCHOR = go.transform;

        }

        // Find the fireDelegate of the root GameObject

        GameObject rootGO = transform.root.gameObject;                       

        if (rootGO.GetComponent<Hero>() != null)
        {                         

            rootGO.GetComponent<Hero>().fireDelegate += Fire;

        }

    }



    public WeaponType type
    {

        get { return (_type); }

        set { SetType(value); }

    }



    public void SetType(WeaponType wpnTyp)
    {

        _type = wpnTyp;

        if (type == WeaponType.none)
        {                                       

            this.gameObject.SetActive(false);

            return;

        }
        else
        {

            this.gameObject.SetActive(true);

        }

        def = Main.GetWeaponDef(_type);                               

        _collarRend.material.color = def.projectileColor;

        lastShotTime = 0; // You can fire immediately after _type is set.    

    }



    public void Fire()
    {

        // If this.gameObject is inactive, return

        if (!gameObject.activeInHierarchy) return;                           

        // If it hasn't been enough time between shots, return

       
        if (MegaPowerupController.clock)
        {
            if (Time.time - lastShotTime < def.shotDelay / 3.0f)
            {
                return;
            }
        }
        else if (Time.time - lastShotTime < def.shotDelay)
        {
            return;
        }

        Projectile proj;

        Vector3 vel = Vector3.up * def.velocity;                             

        if (transform.up.y < 0)
        {

            vel.y = -vel.y;

        }

        switch (type)
        {                                                      

            case WeaponType.blaster:

                if (Hero.hero.ammo >= 1)
                {

                    proj = MakeProjectile();

                    proj.rigid.velocity = vel;

                    if (!MegaPowerupController.clock)
                    {
                        GameAudio.gameAudio.PlayLaser();
                        Hero.hero.RemoveAmmo1();
                    }                    
                }
                break;



            case WeaponType.spread:

                if (Hero.hero.ammo >= 3)
                {
                    proj = MakeProjectile();     // Make middle Projectile

                    proj.rigid.velocity = vel;

                    proj = MakeProjectile();     // Make right Projectile

                    proj.transform.rotation = Quaternion.AngleAxis(30, Vector3.back);

                    proj.rigid.velocity = proj.transform.rotation * vel;

                    proj = MakeProjectile();     // Make left Projectile

                    proj.transform.rotation = Quaternion.AngleAxis(-30, Vector3.back);

                    proj.rigid.velocity = proj.transform.rotation * vel;

                    if (!MegaPowerupController.clock)
                    {
                        GameAudio.gameAudio.PlayBlaster();
                        Hero.hero.RemoveAmmo3();
                    }                    
                }

                break;



        }

    }



    public Projectile MakeProjectile()
    {                                    

        GameObject go = Instantiate<GameObject>(def.projectilePrefab);

        if (transform.parent.gameObject.tag == "Hero")
        {                  

            go.tag = "ProjectileHero";

            go.layer = LayerMask.NameToLayer("ProjectileHero");

        }

        go.transform.position = collar.transform.position;

        go.transform.SetParent(PROJECTILE_ANCHOR, true);                  

        Projectile proj = go.GetComponent<Projectile>();

        proj.type = type;

        lastShotTime = Time.time;                                           

        return (proj);



    }
}

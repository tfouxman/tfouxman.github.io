// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyApuHBwOyaEH0-H4t5intanJbMaEiCw1qM",
    authDomain: "se3316-lab5-12382.firebaseapp.com",
    databaseURL: "https://se3316-lab5-12382.firebaseio.com",
    projectId: "se3316-lab5-12382",
    storageBucket: "se3316-lab5-12382.appspot.com",
    messagingSenderId: "682307821787",
    appId: "1:682307821787:web:c39b39f7b211418196acfe",
    measurementId: "G-EQF530YF2N"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

import { Song } from './song';

describe('Song', () => {
  it('should create an instance', () => {
    expect(new Song()).toBeTruthy();
  });
});

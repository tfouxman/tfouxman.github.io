export class Review {
    key: string;
    title: string;
    body: string;
    rating: number;
    submittedBy: string;
}

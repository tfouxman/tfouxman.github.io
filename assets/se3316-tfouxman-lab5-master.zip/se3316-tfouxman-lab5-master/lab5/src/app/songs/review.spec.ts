import { Review } from './review';

describe('Review', () => {
  it('should create an instance', () => {
    expect(new Review()).toBeTruthy();
  });
});
